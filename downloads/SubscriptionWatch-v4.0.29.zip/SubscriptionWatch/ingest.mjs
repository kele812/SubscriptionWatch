import { createHmac, timingSafeEqual } from "node:crypto";
import { isIP } from "node:net";
import { transaction } from "./model.mjs";
import { evaluate } from "./risk.mjs";
import { finishDeviceRequest } from "./devices.mjs";
export const MAX_AGE = 86400000;
export async function receiveBatch(req, res, { db, decrypt, geo }) {
  const reply = (status, b) => {
    res.writeHead(status, {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    });
    res.end(JSON.stringify(b));
  };
  const publicId = String(req.headers["x-watch-panel"] || "");
  const panel = publicId
    ? db
        .prepare(
          "SELECT p.* FROM panels p JOIN accounts a ON a.id=p.owner WHERE p.public_id=? AND a.disabled=0",
        )
        .get(publicId)
    : db
        .prepare(
          "SELECT p.* FROM panels p JOIN accounts a ON a.id=p.owner WHERE p.legacy=1 AND a.disabled=0",
        )
        .get();
  const timestamp = String(req.headers["x-watch-timestamp"] || ""),
    signature = String(req.headers["x-watch-signature"] || "");
  if (
    !panel ||
    !/^\d{10}$/.test(timestamp) ||
    Math.abs(Date.now() / 1000 - Number(timestamp)) > 300 ||
    !/^[a-f0-9]{64}$/.test(signature)
  )
    return reply(401, { error: "invalid signature or panel" });
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > 524288) return reply(413, { error: "batch too large" });
    chunks.push(c);
  }
  const raw = Buffer.concat(chunks),
    expected = createHmac("sha256", decrypt(panel.secret))
      .update(timestamp + "\n")
      .update(raw)
      .digest();
  if (!timingSafeEqual(expected, Buffer.from(signature, "hex")))
    return reply(401, { error: "invalid signature" });
  let batch;
  try {
    batch = JSON.parse(raw);
  } catch {
    return reply(400, { error: "invalid JSON" });
  }
  const now = Date.now(),
    str = (v, max) => typeof v === "string" && v.length <= max,
    n = (v) => Number.isSafeInteger(v) && v >= 0;
  if (
    batch?.schema !== 1 ||
    !Array.isArray(batch.events) ||
    batch.events.length > 100 ||
    !str(batch.version, 32) ||
    (batch.mode !== undefined && batch.mode !== "request") ||
    (batch.metrics === undefined && batch.mode !== "request") ||
    (batch.metrics !== undefined &&
      (!batch.metrics ||
        !["pending", "dropped", "expired"].every((k) => n(batch.metrics[k])) ||
        (batch.metrics.failures !== undefined && !n(batch.metrics.failures))))
  )
    return reply(422, { error: "invalid batch" });
  for (const e of batch.events)
    if (
      !e ||
      typeof e.event_id !== "string" ||
      !/^[a-f0-9]{32}$/.test(e.event_id) ||
      !n(e.ts) ||
      e.ts < now - MAX_AGE ||
      e.ts > now + 300000 ||
      !n(e.user_id) ||
      e.user_id < 1 ||
      !str(e.email, 254) ||
      !e.email ||
      !str(e.ua, 1024) ||
      !str(e.flag, 128) ||
      !isIP(e.ip) ||
      !isIP(e.peer_ip) ||
      (e.proxy_ip !== undefined && e.proxy_ip !== null && !isIP(e.proxy_ip)) ||
      (e.proxy_name !== undefined &&
        e.proxy_name !== null &&
        !str(e.proxy_name, 128)) ||
      (e.proxy_verified !== undefined &&
        typeof e.proxy_verified !== "boolean") ||
      (e.proxy_verified === true && !e.proxy_ip) ||
      (e.proxy_verified === false && (e.proxy_ip || e.proxy_name)) ||
      !["peer", "trusted_proxy"].includes(e.ip_source) ||
      !Number.isInteger(e.status) ||
      e.status < 100 ||
      e.status > 599 ||
      !n(e.ms) ||
      e.ms > 3600000 ||
      !(e.bytes === null || n(e.bytes)) ||
      (e.token_fingerprint !== undefined &&
        !/^[a-f0-9]{64}$/.test(e.token_fingerprint)) ||
      (e.content_type !== undefined && !str(e.content_type, 128)) ||
      (e.completed_at !== undefined &&
        (!n(e.completed_at) ||
          e.completed_at < e.ts ||
          e.completed_at > now + 300000)) ||
      (e.delivered !== undefined && typeof e.delivered !== "boolean") ||
      (e.delivered === true &&
        (e.status < 200 || e.status >= 300 || e.bytes === 0)) ||
      (e.failure_code !== undefined &&
        (!["review-unavailable", "review-invalid", "review-error"].includes(
          e.failure_code,
        ) ||
          e.status !== 403 ||
          e.delivered === true))
    )
      return reply(422, { error: "invalid event fields" });
  let inserted = 0,
    duplicates = 0,
    discarded = 0;
  try {
    transaction(db, () => {
      const touched = new Map();
      const receipt = db.prepare(
        "INSERT OR IGNORE INTO receipts VALUES(?,?,?)",
      );
      const subject = db.prepare(
        "INSERT INTO subjects(panel,uid,email,verified) VALUES(?,?,?,1) ON CONFLICT(panel,uid) DO UPDATE SET white=CASE WHEN subjects.email=excluded.email THEN subjects.white ELSE 0 END,email=excluded.email,verified=1",
      );
      const visit = db.prepare(
        "INSERT INTO visits(panel,ts,uid,email,ip,ua,peer_ip,ip_source,proxy_ip,proxy_name,proxy_verified,status,ms,bytes,event_id,token_fingerprint,content_type,delivered,review_blocked,review_reasons,ip_whitelisted,failure_code,import_whitelisted,count_key,count_bucket,count_started) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      );
      const sample = db.prepare(
        "INSERT INTO samples(panel,uid,ts,ip,ua,proxy_ip,proxy_name,proxy_verified,status,delivered) VALUES(?,?,?,?,?,?,?,?,?,?)",
      );
      for (const e of batch.events) {
        if (e.ts <= panel.cleared_at) {
          discarded++;
          continue;
        }
        if (!receipt.run(panel.id, e.event_id, now).changes) {
          duplicates++;
          continue;
        }
        const address =
          isIP(e.ip) === 6
            ? new URL(`http://[${e.ip}]/`).hostname.slice(1, -1)
            : e.ip;
        subject.run(panel.id, e.user_id, e.email);
        const reviewed = db
          .prepare(
            "SELECT denied,reason_labels,ip_whitelisted,import_whitelisted,uid,email,ip,ua,count_key,count_bucket,count_started FROM review_decisions WHERE panel=? AND event_id=?",
          )
          .get(panel.id, e.event_id);
        const sameRequest =
          reviewed &&
          reviewed.uid === e.user_id &&
          reviewed.email === e.email &&
          reviewed.ip === e.ip &&
          reviewed.ua === e.ua;
        const importWhitelisted =
          sameRequest && reviewed.import_whitelisted === 1;
        visit.run(
          panel.id,
          e.ts,
          e.user_id,
          e.email,
          address,
          e.ua,
          e.peer_ip,
          e.ip_source,
          e.proxy_ip ?? null,
          e.proxy_name ?? null,
          e.proxy_verified === undefined ? null : Number(e.proxy_verified),
          e.status,
          e.ms,
          e.bytes,
          e.event_id,
          e.token_fingerprint ?? null,
          e.content_type ?? null,
          e.delivered === undefined ? null : Number(e.delivered),
          reviewed?.denied === 1 &&
            [302, 403].includes(e.status) &&
            e.delivered !== true
            ? 1
            : 0,
          reviewed?.denied === 1 &&
            [302, 403].includes(e.status) &&
            e.delivered !== true
            ? reviewed.reason_labels
            : null,
          reviewed?.ip_whitelisted ?? null,
          e.failure_code ?? null,
          reviewed ? Number(importWhitelisted) : null,
          sameRequest ? reviewed.count_key : null,
          sameRequest ? reviewed.count_bucket : null,
          sameRequest ? reviewed.count_started : null,
        );
        if (!importWhitelisted)
          sample.run(
            panel.id,
            e.user_id,
            e.ts,
            address,
            e.ua,
            e.proxy_ip ?? null,
            e.proxy_name ?? null,
            e.proxy_verified === undefined ? null : Number(e.proxy_verified),
            e.status,
            e.delivered === undefined ? null : Number(e.delivered),
          );
        if (reviewed) {
          finishDeviceRequest(db, panel.id, e, reviewed, now);
          const enforced = Number(
            reviewed.denied === 1 &&
              [302, 403].includes(e.status) &&
              e.delivered !== true,
          );
          db.prepare(
            "UPDATE review_decisions SET delivered=?,enforced=? WHERE panel=? AND event_id=?",
          ).run(
            Number(e.delivered === true && e.status >= 200 && e.status < 300),
            enforced,
            panel.id,
            e.event_id,
          );
        }
        if (!importWhitelisted) {
          if (!touched.has(e.user_id)) touched.set(e.user_id, []);
          touched.get(e.user_id).push({
            ts: e.ts,
            ip: address,
            ua: e.ua,
            proxy_ip: e.proxy_ip ?? null,
            proxy_name: e.proxy_name ?? null,
            proxy_verified:
              e.proxy_verified === undefined ? null : Number(e.proxy_verified),
            status: e.status,
            delivered: e.delivered === undefined ? null : Number(e.delivered),
          });
        }
        inserted++;
      }
      if (batch.metrics)
        db.prepare(
          "UPDATE panels SET last_seen=?,pending=?,dropped=?,expired=?,version=?,failures=? WHERE id=?",
        ).run(
          now,
          batch.metrics.pending,
          batch.metrics.dropped,
          batch.metrics.expired,
          batch.version,
          batch.metrics.failures ?? null,
          panel.id,
        );
      else
        db.prepare("UPDATE panels SET last_seen=?,version=? WHERE id=?").run(
          now,
          batch.version,
          panel.id,
        );
      db.prepare("UPDATE panels SET reporting_mode=? WHERE id=?").run(
        batch.mode === "request" ? "request" : "periodic",
        panel.id,
      );
      for (const [uid, fresh] of touched)
        evaluate(db, panel, uid, now, geo, fresh);
    });
  } catch {
    return reply(503, { error: "storage unavailable" });
  }
  return reply(200, {
    ok: true,
    accepted: batch.events.length,
    inserted,
    duplicates,
    discarded,
  });
}
